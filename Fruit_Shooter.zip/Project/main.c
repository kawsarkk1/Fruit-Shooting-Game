#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <graphics.h>

#define ORANGE  RGB(255, 165, 0)
#define LIME RGB(0, 255, 0)
#define CREAM RGB(255, 253, 208)
#define COLOR_1 RGB(240, 240, 240)
#define COLOR_2 RGB(220, 220, 220)
#define COLOR_3 RGB(200, 200, 200)
#define COLOR_4 RGB(180, 180, 180)
#define COLOR_5 RGB(160, 160, 160)
#define COLOR_6 RGB(140, 140, 140)
#define COLOR_7 RGB(120, 120, 120)
#define COLOR_8 RGB(100, 100, 100)
#define COLOR_9 RGB(80, 80, 80)
#define COLOR_10 RGB(60, 60, 60)
#define APPLE_RED RGB(220, 20, 60)
#define WATERMELON_RED RGB(225, 20, 60)
#define MANGO_RED RGB(255, 130, 67)

int playerScore = 0, stage = 1;
int lineX1 = 0, lineX2 = 30, lineY1 = 150, lineY2 = 180;
int fruit1X = 350, fruit1Y = 900;
int fruit2X = 500, fruit2Y = 0;
int fruit3X = 650, fruit3Y = 900;
int fruit4X = 800, fruit4Y = 0;
int fruit5X = 950, fruit5Y = 900;
int fruit7X=1100, fruit7Y=900;

char nstr[10];

void loadGraphics();
int textCenterX(int);
int textCenterY(int);
void instruction();
void gameBody();
void fixDraw();
int moveArrow();
int moveFruit();

struct scoreRecord
{
    char name[10];
    int score;
};

void recordScore(int);
void readScore(struct scoreRecord[]);
bool isHighScore(int, struct scoreRecord[]);
void sortScore(struct scoreRecord[]);
void saveScore(struct scoreRecord[]);

void runGame();

void intro();
void menu();
void game();
void scores();
void about();
void exitGame();

int main()
{
    runGame();
    return 0;
}

void loadGraphics()
{
    int gdriver = DETECT, gmode;
    int scrX = GetSystemMetrics(SM_CXSCREEN), scrY = GetSystemMetrics(SM_CYSCREEN);
    initgraph(&gdriver, &gmode, "C:\\TURBOC3\\BGI");
    initwindow(scrX,scrY,"Fruit Shooter by Kawar and Niloy",0,0);
}

int textCenterX(int width)
{
    int midX = getmaxx() / 2;
    return midX - width / 2;
}

int textCenterY(int height)
{
    int midY = getmaxy() / 2;
    return midY - height / 2;
}

void instruction()
{
    setfillstyle(SOLID_FILL, CREAM);
    rectangle(0, 0, getmaxx(), getmaxy());
    floodfill(500, 500, CREAM);
    setbkcolor(CREAM);
    setcolor(BLACK);
    settextstyle(10,0,5);

    outtextxy(textCenterX(textwidth("You are a skilled archer on a mission to shoot down fruits as")), 250, "You are a skilled archer on a mission to shoot down fruits as");
    outtextxy(textCenterX(textwidth("they fall from the sky. Your task is to control the arrow")), 300, "they fall from the sky. Your task is to control the arrow");
    outtextxy(textCenterX(textwidth("using the arrow keys on your keyboard, aiming precisely to")), 350, "using the arrow keys on your keyboard, aiming precisely to");
    outtextxy(textCenterX(textwidth("hit the fruit mentioned on the screen. Each fruit you hit")), 400, "hit the fruit mentioned on the screen. Each fruit you hit");
    outtextxy(textCenterX(textwidth("adds 10 points to your score, so be quick and accurate to")), 450, "adds 10 points to your score, so be quick and accurate to");
    outtextxy(textCenterX(textwidth("achieve the highest score possible!")), 500, "achieve the highest score possible!");

    while(!kbhit())
    {
        settextstyle(4,0,3);

        setcolor(RED);
        outtextxy(textCenterX(textwidth("ENTER ANY KEY TO CONTINUE")),700,"ENTER ANY KEY TO CONTINUE");
        delay(800);

        setcolor(CREAM);
        outtextxy(textCenterX(textwidth("ENTER ANY KEY TO CONTINUE")),700,"ENTER ANY KEY TO CONTINUE");
        delay(200);
    }
    getch();
    cleardevice();
}

void gameBody()
{
    int bk=(stage-1)/10;

    switch(bk)
    {
    case 0:
        setbkcolor(WHITE);
        break;
    case 1:
        setbkcolor(COLOR_1);
        break;
    case 2:
        setbkcolor(COLOR_2);
        break;
    case 3:
        setbkcolor(COLOR_3);
        break;
    case 4:
        setbkcolor(COLOR_4);
        break;
    case 5:
        setbkcolor(COLOR_5);
        break;
    case 6:
        setbkcolor(COLOR_6);
        break;
    case 7:
        setbkcolor(COLOR_7);
        break;
    case 8:
        setbkcolor(COLOR_8);
        break;
    case 9:
        setbkcolor(COLOR_9);
        break;
    default:
        setbkcolor(COLOR_10);
    }

     // Aam
    int i1=8, j1=-15;
    int mangoPoint[] =
    {
        fruit1X+(0),fruit1Y+(0),
        fruit1X+(7),fruit1Y+(2),
        fruit1X+(12),fruit1Y+(6),
        fruit1X+(16),fruit1Y+(11),
        fruit1X+(19),fruit1Y+(16),
        fruit1X+(22),fruit1Y+(23),
        fruit1X+(22),fruit1Y+(29),
        fruit1X+(20),fruit1Y+(33),
        fruit1X+(19),fruit1Y+(36),
        fruit1X+(18),fruit1Y+(41),
        fruit1X+(22),fruit1Y+(45),
        fruit1X+(25),fruit1Y+(46),
        fruit1X+(30),fruit1Y+(48),
        fruit1X+(30),fruit1Y+(52),
        fruit1X+(27),fruit1Y+(56),
        fruit1X+(16),fruit1Y+(60),
        fruit1X+(9),fruit1Y+(61),
        fruit1X+(1),fruit1Y+(60),
        fruit1X+(-5),fruit1Y+(59),
        fruit1X+(-12),fruit1Y+(56),
        fruit1X+(-20),fruit1Y+(52),
        fruit1X+(-26),fruit1Y+(45),
        fruit1X+(-30),fruit1Y+(36),
        fruit1X+(-30),fruit1Y+(28),
        fruit1X+(-30),fruit1Y+(16),
        fruit1X+(-26),fruit1Y+(11),
        fruit1X+(-21),fruit1Y+(6),
        fruit1X+(-13),fruit1Y+(3),
        fruit1X+(-7),fruit1Y+(2),
        fruit1X+(0),fruit1Y+(0)
    };

    setcolor(BLACK);
    setfillstyle(SOLID_FILL, BLACK);
    bar(fruit1X, fruit1Y, fruit1X+2, fruit1Y-5);
    setfillstyle(SOLID_FILL, MANGO_RED);
    drawpoly(30, mangoPoint);
    fillpoly(30, mangoPoint);

    int mangoLeaves[] =
    {
        fruit1X+i1+(0),fruit1Y+j1+(0),
        fruit1X+i1+(3),fruit1Y+j1+(-5),
        fruit1X+i1+(8),fruit1Y+j1+(-8),
        fruit1X+i1+(15),fruit1Y+j1+(-8),
        fruit1X+i1+(23),fruit1Y+j1+(-8),
        fruit1X+i1+(32),fruit1Y+j1+(-6),
        fruit1X+i1+(38),fruit1Y+j1+(-2),
        fruit1X+i1+(35),fruit1Y+j1+(3),
        fruit1X+i1+(29),fruit1Y+j1+(6),
        fruit1X+i1+(23),fruit1Y+j1+(10),
        fruit1X+i1+(16),fruit1Y+j1+(12),
        fruit1X+i1+(7),fruit1Y+j1+(14),
        fruit1X+i1+(0),fruit1Y+j1+(14),
        fruit1X+i1+(-5),fruit1Y+j1+(13),
        fruit1X+i1+(-7),fruit1Y+j1+(10),
        fruit1X+i1+(-5),fruit1Y+j1+(7),
        fruit1X+i1+(0),fruit1Y+j1+(0)
    };

    setcolor(BLACK);
    setfillstyle(SOLID_FILL, GREEN);
    drawpoly(17, mangoLeaves);
    fillpoly(17, mangoLeaves);

    //Komola
    setfillstyle(SOLID_FILL,ORANGE);
    setcolor(BLACK);
    ellipse(fruit2X, fruit2Y, 0, 360, 30, 30);
    fillellipse(fruit2X,fruit2Y, 30, 30);

    //pata
    setcolor(GREEN);
    setlinestyle(0,0,3);
    line(fruit2X, fruit2Y - 25, fruit2X, fruit2Y - 30);
    line(fruit2X+1, fruit2Y - 25, fruit2X+1, fruit2Y - 30);

    //Lebu
    setcolor(BLACK);
    ellipse(fruit3X,fruit3Y, 0, 360, 15, 25);
    setfillstyle(SOLID_FILL, LIME);
    fillellipse(fruit3X,fruit3Y, 15, 25);

    //pata
    setcolor(BROWN);
    setlinestyle(0,0,3);
    line(fruit3X, fruit3Y - 28, fruit3X, fruit3Y - 22);
    line(fruit3X+1, fruit3Y - 28, fruit3X+1, fruit3Y - 22);

    // TORMUJ
    setfillstyle(SOLID_FILL,GREEN);
    fillellipse(fruit4X,fruit4Y, 45, 55);
    setcolor(BLACK);
    ellipse(fruit4X,fruit4Y, 0, 360, 45, 55);
    setfillstyle(SOLID_FILL, WATERMELON_RED);
    fillellipse(fruit4X,fruit4Y, 35, 45);
    setcolor(COLOR_3);
    ellipse(fruit4X,fruit4Y, 0, 360, 35, 45);

    //Seed
    setcolor(BLACK);
    setlinestyle(9,0,3);
    line(fruit4X, fruit4Y, fruit4X, fruit4Y+2);
    line(fruit4X+15, fruit4Y, fruit4X+17, fruit4Y+2);
    line(fruit4X-15, fruit4Y, fruit4X-17, fruit4Y+2);
    line(fruit4X, fruit4Y+15, fruit4X+2, fruit4Y+17);
    line(fruit4X, fruit4Y-15, fruit4X+2, fruit4Y-17);
    line(fruit4X+10, fruit4Y+10, fruit4X+12, fruit4Y+12);
    line(fruit4X-10, fruit4Y+10, fruit4X-12, fruit4Y+12);
    line(fruit4X+10, fruit4Y-10, fruit4X+12, fruit4Y-12);
    line(fruit4X-10, fruit4Y-10, fruit4X-12, fruit4Y-12);

    // Apple
    int points[] =
    {
        fruit5X, fruit5Y-5,
        fruit5X+10, fruit5Y-10,
        fruit5X+20, fruit5Y-15,
        fruit5X+30, fruit5Y-10,
        fruit5X+40, fruit5Y,
        fruit5X+46, fruit5Y+10,
        fruit5X+46, fruit5Y+20,
        fruit5X+40, fruit5Y+30,
        fruit5X+30, fruit5Y+40,
        fruit5X+8, fruit5Y+46,
        fruit5X+5, fruit5Y+40,

        fruit5X, fruit5Y+36,

        fruit5X-5, fruit5Y+40,
        fruit5X-8, fruit5Y+46,
        fruit5X-30, fruit5Y+40,
        fruit5X-40, fruit5Y+30,
        fruit5X-46, fruit5Y+20,
        fruit5X-46, fruit5Y+10,
        fruit5X-40, fruit5Y,
        fruit5X-30, fruit5Y-10,
        fruit5X-20, fruit5Y-15,
        fruit5X-10, fruit5Y-10,
        fruit5X, fruit5Y-5,
    };

    setfillstyle(SOLID_FILL, APPLE_RED);
    setcolor(BLACK);
    drawpoly(23, points);
    fillpoly(23, points);


    //Pata
    setfillstyle(SOLID_FILL, BROWN);
    bar(fruit5X, fruit5Y-8, fruit5X+5, fruit5Y-23);
    setcolor(BLACK);
    rectangle(fruit5X, fruit5Y-8, fruit5X+5, fruit5Y-23);

    setfillstyle(SOLID_FILL, GREEN);
    setcolor(GREEN);
    int leafPoints[] = {fruit5X+5,fruit5Y-25, fruit5X+15,fruit5Y-35, fruit5X+40,fruit5Y-40, fruit5X+65,fruit5Y-40, fruit5X+55,fruit5Y-30, fruit5X+25,fruit5Y-20, fruit5X+5,fruit5Y-25};
    drawpoly(7, leafPoints);
    fillpoly(6, leafPoints);
    setcolor(BLACK);
    drawpoly(7, leafPoints);

    //Banana
    int i7=31, j7=-120;
    setcolor(BLACK);
    setfillstyle(SOLID_FILL, YELLOW);

    int bananaPoint1[] =
    {
        fruit7X+(38),fruit7Y+(-109),
        fruit7X+(43),fruit7Y+(-106),
        fruit7X+(49),fruit7Y+(-100),
        fruit7X+(55),fruit7Y+(-94),
        fruit7X+(61),fruit7Y+(-92),
        fruit7X+(68),fruit7Y+(-88),
        fruit7X+(76),fruit7Y+(-86),
        fruit7X+(87),fruit7Y+(-86),
        fruit7X+(97),fruit7Y+(-88),
        fruit7X+(105),fruit7Y+(-92),
        fruit7X+(116),fruit7Y+(-95),
        fruit7X+(123),fruit7Y+(-99),
        fruit7X+(131),fruit7Y+(-103),
        fruit7X+(139),fruit7Y+(-103),
        fruit7X+(145),fruit7Y+(-98),
        fruit7X+(144),fruit7Y+(-90),
        fruit7X+(138),fruit7Y+(-83),
        fruit7X+(128),fruit7Y+(-73),
        fruit7X+(118),fruit7Y+(-67),
        fruit7X+(109),fruit7Y+(-63),
        fruit7X+(96),fruit7Y+(-60),
        fruit7X+(86),fruit7Y+(-59),
        fruit7X+(78),fruit7Y+(-59),
        fruit7X+(65),fruit7Y+(-61),
        fruit7X+(54),fruit7Y+(-64),
        fruit7X+(42),fruit7Y+(-69),
        fruit7X+(36),fruit7Y+(-75),
        fruit7X+(31),fruit7Y+(-79),
        fruit7X+(25),fruit7Y+(-90),
        fruit7X+(24),fruit7Y+(-101),
        fruit7X+(27),fruit7Y+(-108),
        fruit7X+(33),fruit7Y+(-111),
        fruit7X+(40),fruit7Y+(-106),
        fruit7X+(-200),fruit7Y+(-200),
        fruit7X+(38),fruit7Y+(-109)
    };
    drawpoly(33, bananaPoint1);
    fillpoly(33, bananaPoint1);
    setfillstyle(SOLID_FILL, GREEN);
    bar(fruit7X+i7, fruit7Y+j7, fruit7X+i7+8, fruit7Y+j7+15);

    //Arrow
    setfillstyle(SOLID_FILL, BLACK);
    setlinestyle(0,0,3);
    setcolor(BLACK);
    bar (lineX1, lineY1, lineX2, lineY2);
}

int moveArrow()
{
    char ch;
    int i=30;
    if(kbhit())
    {
        ch=getch();
        switch(ch)
        {
        case 27:
            return 1;
        case 77:
            //right
            if(lineX2<getmaxx())
            {
                lineX1+=i;
                lineX2+=i;
            }
            else
            {
                lineX1=0, lineX2=30;
            }
            break;
        case 75:
            //left
            if(lineX1>0)
            {
                lineX1-=i;
                lineX2-=i;
            }
            else
            {
                lineX1=getmaxx()-30, lineX2=getmaxx();
            }
            break;
        case 72:
            //up
            if(lineY1>0)
            {
                lineY1-=i;
                lineY2-=i;
            }
            else
            {
                lineY1=getmaxy()-30, lineY2=getmaxy();
            }
            break;
        case 80:
            //down
            if(lineY2<getmaxy())
            {
                lineY1+=i;
                lineY2+=i;
            }
            else
            {
                lineY1=0, lineY2=30;
            }
            break;
        }
    }
}

void fixDraw()
{
    int j = rand()%400;
    fruit1X=j+(getmaxx()*0.1);
    fruit2X=j+(getmaxx()*0.2);
    fruit3X=j+(getmaxx()*0.3);
    fruit4X=j+(getmaxx()*0.4);
    fruit5X=j+(getmaxx()*0.5);
    fruit7X=j+(getmaxx()*0.7);

    if(fruit1X > (getmaxx()-70))
        fruit1X = 450;
    if(fruit2X > (getmaxx()-70))
        fruit2X = 600;
    if(fruit3X > (getmaxx()-70))
        fruit3X = 750;
    if(fruit4X > (getmaxx()-70))
        fruit4X = 300;
    if(fruit5X > (getmaxx()-70))
        fruit5X = 150;
    if(fruit7X > (getmaxx()-70))
        fruit7X = 300;

    fruit1Y=getmaxy();
    fruit2Y=0;
    fruit3Y=getmaxy();
    fruit4Y=0;
    fruit5Y=getmaxy();
    fruit7Y=getmaxy();


    lineX1=0,lineX2=30;
}

int moveFruit()
{
    setcolor(BLACK);
    settextstyle(0,0,2);
    outtextxy(50,40,"TARGET:");
    outtextxy(50,80,"SCORE: ");
    sprintf(nstr,"%d",playerScore);
    outtextxy(150,80,nstr);

    int no = stage%11;

    fruit1Y -= 4;
    fruit2Y += 4;
    fruit3Y -= 4;
    fruit4Y += 4;
    fruit5Y -= 4;
    fruit7Y -= 4;

    switch(no)
    {
    case 0:
        outtextxy(150,40,"APPLE");
        if(lineX2>=fruit5X-45 && lineX1<=fruit5X+45 && lineY2>=fruit5Y-15 && lineY1<=fruit5Y+45)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 1:
        outtextxy(150,40,"MANGO");
        if(lineX2>=fruit1X-50 && lineX1<=fruit1X+50 && lineY2>=fruit1Y-70 && lineY1<=fruit1Y+70)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 2:
        outtextxy(150,40,"ORANGE");
        if(lineX2>=fruit2X-60 && lineX1<=fruit2X+60 && lineY2>=fruit2Y-60 && lineY1<=fruit2Y+60)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 3:
        outtextxy(150,40,"LEMON");
        if(lineX2>=fruit3X-40 && lineX1<=fruit3X+40 && lineY2>=fruit3Y-55 && lineY1<=fruit3Y+55)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 4:
        outtextxy(150,40,"WATERMELON");
        if(lineX2>=fruit4X-60 && lineX1<=fruit4X+60 && lineY2>=fruit4Y-75 && lineY1<=fruit4Y+75)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 5:
        outtextxy(150,40,"BANANA");
        if(lineX2>=fruit7X+20 && lineX1<=fruit7X+150 && lineY2>=fruit7Y-120 && lineY1<=fruit7Y-55)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 6:
        outtextxy(150,40,"MANGO");
        if(lineX2>=fruit1X-50 && lineX1<=fruit1X+50 && lineY2>=fruit1Y-70 && lineY1<=fruit1Y+70)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 7:
        outtextxy(150,40,"ORANGE");
        if(lineX2>=fruit2X-60 && lineX1<=fruit2X+60 && lineY2>=fruit2Y-60 && lineY1<=fruit2Y+60)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 8:
        outtextxy(150,40,"LEMON");
        if(lineX2>=fruit3X-40 && lineX1<=fruit3X+40 && lineY2>=fruit3Y-55 && lineY1<=fruit3Y+55)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 9:
        outtextxy(150,40,"WATERMELON");
        if(lineX2>=fruit4X-60 && lineX1<=fruit4X+60 && lineY2>=fruit4Y-75 && lineY1<=fruit4Y+75)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    case 10:
        outtextxy(150,40,"ORANGE");
        if(lineX2>=fruit2X-60 && lineX1<=fruit2X+60 && lineY2>=fruit2Y-60 && lineY1<=fruit2Y+60)
        {
            stage++;
            playerScore=playerScore+10;
            fixDraw();
        }
        else if(fruit1Y<=10)
        {
            return 0;
        }
        break;
    }

    return 1;
}

void recordScore(int n)
{
    struct scoreRecord records[6];
    struct scoreRecord newScore;

    readScore(records);

    newScore.score = n;
    if(isHighScore(newScore.score, records))
    {
        loadGraphics();
        setbkcolor(BLACK);
        settextstyle(4,0,3);
        setcolor(WHITE);
        outtextxy(textCenterX(textwidth("YOU HAVE SET A NEW RECORD")), 200, "YOU HAVE SET A NEW RECORD");
        while(!kbhit())
        {
            settextstyle(4,0,3);

            setcolor(WHITE);
            outtextxy(textCenterX(textwidth("PRESS ANY KEY AND ENTER YOUR NAME")),700,"PRESS ANY KEY AND ENTER YOUR NAME");
            delay(1000);

            setcolor(BLACK);
            outtextxy(textCenterX(textwidth("PRESS ANY KEY AND ENTER YOUR NAME")),700,"PRESS ANY KEY AND ENTER YOUR NAME");
            delay(500);
        }
        closegraph();

        printf("Enter your name: ");
        scanf("%s", newScore.name);

        records[5].score = newScore.score;
        strcpy(records[5].name, newScore.name);

        sortScore(records);
        saveScore(records);
    }
}

void readScore(struct scoreRecord records[])
{
    FILE* file = fopen("High_Scores.txt", "r");
    if (file != NULL)
    {
        for (int i = 0; i < 6; i++)
        {
            if (fscanf(file, "%s %d", records[i].name, &records[i].score) != 2)
            {
                strcpy(records[i].name, "Blank");
                records[i].score = 0;
            }
        }
        fclose(file);
    }
    else
    {
        for (int i = 0; i < 6; i++)
        {
            strcpy(records[i].name, "Blank");
            records[i].score = 0;
        }
    }
}

bool isHighScore(int newScore, struct scoreRecord records[])
{
    for (int i = 0; i < 5; i++)
    {
        if (newScore > records[i].score)
        {
            return true;
        }
    }
    return false;
}

void sortScore(struct scoreRecord records[])
{
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5 - i ; j++)
        {
            if (records[j].score < records[j + 1].score)
            {
                int tempScore = records[j].score;
                records[j].score = records[j+1].score;
                records[j+1].score = tempScore;

                char tempName[15];
                strcpy(tempName, records[j].name);
                strcpy(records[j].name, records[j+1].name);
                strcpy(records[j+1].name, tempName);
            }
        }
    }
}

void saveScore(struct scoreRecord records[])
{
    FILE* file = fopen("High_Scores.txt", "w");
    if (file != NULL)
    {
        for (int i = 0; i < 5; i++)
        {
            fprintf(file, "%s %d\n", records[i].name, records[i].score);
        }
        fclose(file);
    }
}

void runGame()
{
    intro();
    menu();
    exitGame();
}

void intro()
{
    loadGraphics();

    setcolor(LIGHTBLUE);
    settextstyle(3,0,8);
    outtextxy(textCenterX(textwidth("WELCOME TO THE WORLD OF")),200,"WELCOME TO THE WORLD OF");

    setcolor(RED);
    settextstyle(10,0,7);
    outtextxy(textCenterX(textwidth("FRUIT HUNTING")),350,"FRUIT HUNTING");
    delay(1000);

    setcolor(YELLOW);
    settextstyle(4,0,4);
    outtextxy(textCenterX(textwidth("Wishing you good luck")),500,"Wishing you good luck");
    delay(1000);

    while(!kbhit())
    {
        settextstyle(4,0,3);

        setcolor(WHITE);
        outtextxy(textCenterX(textwidth("ENTER ANY KEY TO CONTINUE")),700,"ENTER ANY KEY TO CONTINUE");
        delay(1000);

        setcolor(BLACK);
        outtextxy(textCenterX(textwidth("ENTER ANY KEY TO CONTINUE")),700,"ENTER ANY KEY TO CONTINUE");
        delay(500);
    }

    getch();
    closegraph();
}

void menu()
{
    int x,y;
    loadGraphics();

    settextstyle(3,0,10);

    setcolor(YELLOW);
    rectangle(480, 90, 1055, 235);

    setcolor(WHITE);
    outtextxy(textCenterX(textwidth("NEW GAME")),100,"NEW GAME");

    setcolor(YELLOW);
    rectangle(412, 290, 1122, 435);

    setcolor(WHITE);
    outtextxy(textCenterX(textwidth("HIGH SCORES")),300,"HIGH SCORES");

    setcolor(YELLOW);
    rectangle(582, 490, 952, 635);

    setcolor(WHITE);
    outtextxy(textCenterX(textwidth("ABOUT")),500,"ABOUT");

    setcolor(YELLOW);
    rectangle(645, 690, 890, 835);

    setcolor(WHITE);
    outtextxy(textCenterX(textwidth("EXIT")),700,"EXIT");

    while(1)
    {
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            x = mousex();
            y = mousey();

            if(x>=480 && x<=1055  &&  y>=90 && y<=235)
            {
                closegraph();
                game();
            }
            else  if(x>=412 && x<=1122  &&  y>=290 && y<=435)
            {
                closegraph();
                scores();
            }
            else  if(x>=582 && x<=952  &&  y>=490 && y<=635)
            {
                closegraph();
                about();
            }
            else if (x >= 645 && x <= 890 && y >= 690 && y <= 835)
            {
                return;
            }
        }
    }
}

void game()
{
    loadGraphics();
    instruction();

    int end, esc;

    while(1)
    {
        gameBody();
        end=moveFruit();
        esc=moveArrow();
        delay(25);
        cleardevice();
        if(end==0  || esc==1)
        {
            break;
        }
    }

    setcolor(BLACK);
    settextstyle(0,0,2);
    outtextxy(textCenterX(textwidth("SCORE: ")), 300,"SCORE: ");
    sprintf(nstr,"%d",playerScore);
    outtextxy(textCenterX(textwidth("SCORE: "))+100, 300, nstr);
    setcolor(RED);
    settextstyle(10,0,5);
    outtextxy(textCenterX(textwidth("GAME OVER")), textCenterY(textwidth("GAME OVER"))+300,"GAME OVER");
    getch();
    closegraph();
    recordScore(playerScore);

    playerScore = 0;
    stage = 1;
    lineX1 = 0;
    lineX2 = 30;
    lineY1 = 150;
    lineY2 = 180;
    fruit1X = 450;
    fruit1Y = 900;
    fruit2X = 600;
    fruit2Y = 0;
    fruit3X = 750;
    fruit3Y = 900;
    fruit4X = 900;
    fruit4Y = 0;

    menu();
}

void scores()
{
    FILE *rptr = fopen("High_Scores.txt", "r");

    if (rptr == NULL)
    {
        fclose(rptr);
        loadGraphics();

        setcolor(RED);
        settextstyle(10, 0, 10);
        outtextxy(textCenterX(textwidth("No recorded scores")), textCenterY(textheight("No recorded scores")), "No recorded scores");

        while (!kbhit())
        {
            settextstyle(4, 0, 3);

            setcolor(WHITE);
            outtextxy(textCenterX(textwidth("ENTER ANY KEY TO GO BACK")), 700, "ENTER ANY KEY TO GO BACK");
            delay(1000);

            setcolor(BLACK);
            outtextxy(textCenterX(textwidth("ENTER ANY KEY TO GO BACK")), 700, "ENTER ANY KEY TO GO BACK");
            delay(500);
        }

        getch();
        closegraph();
    }
    else
    {
        struct scoreRecord records[6];
        readScore(records);

        loadGraphics();

        setcolor(YELLOW);
        settextstyle(4, 0, 5);


        outtextxy(50, 100, "NAME");
        outtextxy(1000, 100, "SCORE");

        setcolor(WHITE);
        settextstyle(4, 0, 4);

        outtextxy(0, 200, "1.");
        outtextxy(0, 300, "2.");
        outtextxy(0, 400, "3.");
        outtextxy(0, 500, "4.");
        outtextxy(0, 600, "5.");

        for (int i = 0; i < 5; i++)
        {
            char newscr[5];
            sprintf(newscr, "%d", records[i].score);
            outtextxy(50, 100 * (i + 2), records[i].name);
            outtextxy(1000, 100 * (i + 2), newscr);
        }

        while (!kbhit())
        {
            settextstyle(4, 0, 3);

            setcolor(WHITE);
            outtextxy(textCenterX(textwidth("ENTER ANY KEY TO GO BACK")), 700, "ENTER ANY KEY TO GO BACK");
            delay(1000);

            setcolor(BLACK);
            outtextxy(textCenterX(textwidth("ENTER ANY KEY TO GO BACK")), 700, "ENTER ANY KEY TO GO BACK");
            delay(500);
        }

        getch();
        closegraph();
    }

    menu();
}

void about()
{
    loadGraphics();
    setcolor(YELLOW);
    settextstyle(4, 0, 6);
    outtextxy(100, 100, "ABOUT");
    setcolor(WHITE);
    settextstyle(8, 0, 5);
    outtextxy(100, 250, "This game was made by-");
    outtextxy(100, 300, "Md. Kawsar Khan");
    outtextxy(100, 340, "CE21025");
    outtextxy(100, 400, "Sarkar Fahim Foysal Niloy");
    outtextxy(100, 440, "CE21028");
    outtextxy(100, 510, "Under the supervision of-");
    outtextxy(100, 550, "Md. Mosaddik Hasan Sir");
    outtextxy(100, 590, "Associate Professor");
    outtextxy(100, 630, "Department of CSE");
    outtextxy(100, 670, "Mawlana Bhashani Science and Technology University");
    getch();
    closegraph();

    menu();
}

void exitGame()
{
    loadGraphics();

    setcolor(LIGHTBLUE);
    settextstyle(3, 0, 8);
    outtextxy(textCenterX(textwidth("THANK YOU FOR PLAYING")), 200, "THANK YOU FOR PLAYING");


    setcolor(YELLOW);
    settextstyle(10, 0, 7);
    outtextxy(textCenterX(textwidth("FRUIT HUNTER")), 350, "FRUIT HUNTER");
    delay(500);

    setcolor(RED);
    settextstyle(10, 0, 7);
    outtextxy(textCenterX(textwidth("FRUIT HUNTER")), 350, "FRUIT HUNTER");
    delay(500);

    setcolor(YELLOW);
    settextstyle(10, 0, 7);
    outtextxy(textCenterX(textwidth("FRUIT HUNTER")), 350, "FRUIT HUNTER");
    delay(500);

    setcolor(RED);
    settextstyle(10, 0, 7);
    outtextxy(textCenterX(textwidth("FRUIT HUNTER")), 350, "FRUIT HUNTER");
    delay(500);

    exit(0);
}
